# ------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   EAkici, 11/22/2018, Added code to complete assignment 5
#   EAkici, 11/28/2018, Added class and functions to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# ------------------------------------------------- #


# -- Data -- #
# Declare variables and constants
# objFileName = Name of todo text file
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection


objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []
strMenu = """
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """
strChoice = ""


# -- Input/Output -- #
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)


# -- Processing -- #


# - Define class and functions - #


class WorkWithToDo(object):
    # This class manages the ToDo.txt file

    @staticmethod
    def LoadFile(filename):
        # This function loads data from a file
        objFile = open(filename, "r")
        for line in objFile:
            line = line.strip('\n')                                                     # Strip \n
            strData = line.split(",")                                                   # Comma delimited
            task = strData[0]                                                           # Assign first element to "Task"
            priority = strData[1]                                                       # Assign second element to "Priority"
            dicRow = {"Task": task, "Priority": priority}                               # Create dictionary element
            lstTable.append(dicRow)                                                     # Assembly table of dictionaries
        objFile.close()                                                                 # Close file
        return lstTable                                                                 # Output [lstTable] when function ends

    @staticmethod
    def ShowMenu():
        # This function shows the menu of options and allows user to choose what to do
        print(strMenu)                                                                  # Print menu of options to user
        strChoice = str(input("Which option would you like to perform? [1 to 5]\n"))    # Request user input to drive program
        print()                                                                         # Add additional line
        return strChoice                                                                # Output 'strChoice' when function ends

    @staticmethod
    def ShowData(lstTable):
        # This function shows the current data
        print('Here is your To Do list:\n', 'Task ( Priority )', sep="")
        print('----------------------------')
        print('----------------------------')
        for dicRow in lstTable:
            print(dicRow["Task"], '(', dicRow["Priority"], ')')                         # Print current ToDo list
        print('----------------------------')

    @staticmethod
    def AddData(lstTable):
        # This function lets the user add a task and priority
        taskUserInput = input("Enter Task Name:\n")                                     # Request user input for new Task
        priUserInput = input("Enter Priority:\n")                                       # Request user input for new Priority
        newData = {"Task": taskUserInput, "Priority": priUserInput}                     # Generate new dictionary element
        lstTable.append(newData)                                                        # Append new data to table
        return lstTable                                                                 # Output [lstTable] when function ends

    @staticmethod
    def DelData(lstTable):
        # This function lets the user remove a task and priority
        value = False                                                                   # Initialize "False" for error check
        strRemove = input("Input the name of the TASK to remove:\n")                    # Request user input for item removal
        for row in lstTable:                                                            # Loop through each dictionary
            if strRemove in row["Task"]:                                                # If user input "Task" is found
                del lstTable[lstTable.index(row)]                                       # Delete index from table containing that dictionary
                value = True                                                            # Assign "True" for error check
        if value is False:
            print('Error: No such task!\n')
        return lstTable                                                                 # Output [lstTable] when function ends

    @staticmethod
    def SaveFile(lstTable):
        # This function saves the data to a file
        todoFile = open('Todo.txt', 'w')                                                # Open file for writing
        for dicRow in lstTable:                                                         # Loop through each row
            todoFile.write(str(dicRow["Task"]) + ',' + str(dicRow["Priority"]) + '\n')  # Write each row on sep line
        todoFile.close()                                                                # Closes file
        print("Data has been saved to a file!")

    @staticmethod
    def ExitProg():
        # This function exits the program
        print("Program has exited, thank you!")

# ------------------------------ #

# - Call Functions - #

# Step 1 - Load data from a file
lstTable = WorkWithToDo.LoadFile(objFileName)

# Step 2 - Display a menu of choices to the user
while True:
    strChoice = WorkWithToDo.ShowMenu()

# Step 3 - Show the current items in the table
    if strChoice.strip() == '1':
        WorkWithToDo.ShowData(lstTable)
        continue

# Step 4 - Add a new item to the list/table
    elif strChoice.strip() == '2':
        lstTable = WorkWithToDo.AddData(lstTable)                                       # Append dictionary to data table
        continue

# Step 5 - Remove a new item to the list/table
    elif strChoice == '3':
        lstTable = WorkWithToDo.DelData(lstTable)                                       # Error check for incorrect user input
        continue

# Step 6 - Save tasks to the ToDo.txt file
    elif strChoice == '4':
        WorkWithToDo.SaveFile(lstTable)
        continue

# Step 7 - Exit the program
    elif strChoice == '5':
        WorkWithToDo.ExitProg()
        break                                                                           # Exit the program
# ------------------------------- #
