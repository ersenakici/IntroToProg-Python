# ------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   EAkici, 11/22/2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# ------------------------------------------------- #

# -- Data -- #
# Declare variables and constants
# objFileName = Name of todo text file
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []
strMenu = """
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """
strChoice = ""

# -- Input/Output -- #
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing -- #
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/table

# Step 5
# Remove an item from the list/table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# ------------------------------- #


# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add each dictionary "row" to a python list "table"

objFile = open(objFileName, "r")
for line in objFile:
    line = line.strip('\n')                                                             # Strip \n
    strData = line.split(",")                                                           # Comma delimited
    task = strData[0]                                                                   # Assign first element to "Task"
    priority = strData[1]                                                               # Assign second element to "Priority"
    dicRow = {"Task": task, "Priority": priority}                                       # Create dictionary element
    lstTable.append(dicRow)                                                             # Assembly table of dictionaries

# Step 2 - Display a menu of choices to the user

while True:
    print(strMenu)                                                                      # Print menu of options to user
    strChoice = str(input("Which option would you like to perform? [1 to 5]\n"))        # Request user input to drive program
    print()                                                                             # Adding a new line

# Step 3 - Show the current items in the table

    if strChoice.strip() == '1':
        print('Here is your To Do list:\n', 'Task ( Priority )', sep="")
        print('----------------------------')
        print('----------------------------')
        for dicRow in lstTable:
            print(dicRow["Task"], '(', dicRow["Priority"], ')')                         # Print current ToDo list
        print('----------------------------')
        continue

# Step 4 - Add a new item to the list/table

    elif strChoice.strip() == '2':
        taskUserInput = input("Enter Task Name:\n")                                     # Request user input for new Task
        priUserInput = input("Enter Priority:\n")                                       # Request user input for new Priority
        newData = {"Task": taskUserInput, "Priority": priUserInput}                     # Generate new dictionary element
        lstTable.append(newData)                                                        # Append dictionary to data table
        continue

# Step 5 - Remove a new item to the list/table

    elif strChoice == '3':
        value = False                                                                   # Initialize "False" for error check
        strRemove = input("Input the name of the TASK to remove:\n")                    # Request user input for item removal
        for row in lstTable:                                                            # Loop through each dictionary
            if strRemove in row["Task"]:                                                # If user input "Task" is found
                del lstTable[lstTable.index(row)]                                       # Delete index from table containing that dictionary
                value = True                                                            # Assign "True" for error check
        if value is False:
            print('Error: No such task!\n')                                             # Error check for incorrect user input
        continue

# Step 6 - Save tasks to the ToDo.txt file

    elif strChoice == '4':
        todoFile = open('Todo.txt', 'w')                                                # Open file for writing
        for dicRow in lstTable:                                                         # Loop through each row
            todoFile.write(str(dicRow["Task"]) + ',' + str(dicRow["Priority"]) + '\n')  # Write each row on sep line
        todoFile.close()                                                                # Closes file
        print("Data has been saved to a file!")
        continue

# Step 7 - Exit the program

    elif strChoice == '5':
        print("Program has exited, thank you!")
        break                                                                           # Exit the program
