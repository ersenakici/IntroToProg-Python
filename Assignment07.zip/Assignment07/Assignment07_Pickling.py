# ------ Error Handling Example ------ #
# Title: Picking in Python
# Dev:   EAkici
# Date:  December 3, 2018
# ChangeLog: (Who, When, What)
#
# Web References:
# https://www.datacamp.com/community/tutorials/pickle-python-tutorial
# https://www.geeksforgeeks.org/understanding-python-pickling-example/
# ------------------------------------ #

# -- Import Pickle Module -- #


import pickle


# -- Data -- #
# Declare variables and constants
# binFileName = Name of binary file
# dicDB = A dictionary database containing guest names and invite categories

binFileName = 'Guest_List.dat'
dicDB = {}


# -- Processing -- #


def create_list():
    # This function creates a simple dictionary to store guest names
    Ersen = {'Name': 'Ersen Akici', 'Category': 'A'}
    Andrea = {'Name': 'Andrea Ruge', 'Category': 'A'}
    Mom = {'Name': 'Jale Akici', 'Category': 'A'}
    Dad = {'Name': 'Husnu Akici', 'Category': 'A'}

    # Nest dictionary elements into database dictionary
    dicDB['Ersen'] = Ersen
    dicDB['Andrea'] = Andrea
    dicDB['Mom'] = Mom
    dicDB['Dad'] = Dad

    # Create a binary file that stores the dictionary database by pickling
    bin_file = open(binFileName, 'wb')                                          # Write to a binary file
    pickle.dump(dicDB, bin_file)                                                # Pickle dicDB to file 'bin_file'
    bin_file.close()                                                            # Close file


def load_list():
    # Load data from binary by unpickling and print the contents of the dictionary
    bin_file = open(binFileName, 'rb')                                          # Read a binary file
    loadedDB = pickle.load(bin_file)                                            # Assign dicDB to binary file contents

    # Print dictionary elements to view guest list
    for i in loadedDB:
        print(i, '=>', dicDB[i])


# -- Input/Output -- #


create_list()
load_list()
