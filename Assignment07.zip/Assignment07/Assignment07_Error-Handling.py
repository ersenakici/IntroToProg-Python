# ------ Error Handling Example ------ #
# Title: Error Handling in Python
# Dev:   EAkici
# Date:  December 3, 2018
# ChangeLog: (Who, When, What)
#
# Web References:
# https://realpython.com/python-exceptions/
# ------------------------------------ #

# -- Data -- #
# Declare variables and constants
# objFile = An object that represents a file
# objFileName = Name of Guest_List.txt file
# strUserInput = A string holding user input
# strGreeting = A string holding user input

objFile = None
objFileName = 'Guest_List.txt'
strUserInput = None
strGreeting = '\nWelcome!  This program helps manage your wedding guest list.\n'


# -- Processing -- #


def GreetUser(Greeting):
    # This function greets the user and performs an ID check
    print(Greeting)                                                                         # Greet user
    accesscontrol = input('Plese type your name to continue:\n')                            # Input for authorization
    assert (accesscontrol == 'Ersen Akici'), "Sorry, only Ersen can edit this list!"        # Define AssertionError


def WriteGuestListInput(File):
    # This function gathers user input to write to the guest list
    while True:
        strUserInput = input("Type in a Guest ID #, Guest Name, and Invite"                 # Define guest info
                             " Category (A/B) - or 'exit' to terminate:\n")
        if (strUserInput.lower() == "exit"): break                                          # Allow user to break
        else: File.write(strUserInput + "\n")                                               # Write data


def ReadAllFileData(File, Message):
    # This function reads the data file
    print(Message)                                                                          # Print header
    File.seek(0)                                                                            # Move cursor to beginning
    print(File.read())                                                                      # Print file contents


# -- Input/Output -- #

try:                                                                                        # Try/Except for ID check
    GreetUser(strGreeting)                                                                  # Greet user, check ID
except AssertionError as e:                                                                 # If AssertionError occurs
    print("Error: " + str(e))                                                               # Notify user
else:                                                                                       # If no errors
    try:                                                                                    # Try/Except for data
        objFile = open(objFileName, "r+")                                                   # Read/Write objFileName
    except FileNotFoundError as e:                                                          # If file doesn't exist
        objFile = open(objFileName, "a")                                                    # Create file by append
        objFile = open(objFileName, "r+")                                                   # Read/Write objFileName
        print('Attention!: ' + objFileName + ' was created in working directory\n\n'        # Notify user of file create
              + 'No data currently exists.\n')
        WriteGuestListInput(objFile)                                                        # Execute guest list func
        ReadAllFileData(objFile, "Here is the data that was saved:\n")                      # Execute read data func
        objFile.close()                                                                     # Close file
    except Exception in e:                                                                  # For all other errors
        print("Error: " + str(e))                                                           # Print out
    else:                                                                                   # If no errors, continue
        ReadAllFileData(objFile, "\nHere is the current data:\n")
        WriteGuestListInput(objFile)
        ReadAllFileData(objFile, "\nHere is the data that was saved:\n")
        objFile.close()
finally:                                                                                # Exit message
    print("\nProgram has ended, thank you!")
